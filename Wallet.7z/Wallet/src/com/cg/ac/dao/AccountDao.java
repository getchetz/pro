package com.cg.ac.dao;

import java.util.HashMap;
import com.cg.ac.bean.Account;
import com.cg.ac.exception.AccountException;


public interface AccountDao {
	public String createAccount(Account account)throws AccountException;
	public Account showBalance(String accountNo)throws AccountException;
	public Account deposite(String accountNo, double amount)throws AccountException;
	public Account withDraw(String accountNo, double amount)throws AccountException;
	public Account fundTransfer(String accountNo,String accountNo1, double amount) throws AccountException;
	public void printTransaction()throws AccountException;
	
	

}
