package com.cg.pms.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.pms.dao.IProductDao;
import com.cg.pms.dao.IprouctDaoImpl;
import com.cg.pms.dto.Product;
import com.cg.pms.exceptions.PMSException;

public class ProductServiceImpl implements IproductService {

	IProductDao productDao = new IprouctDaoImpl();

	public void validateId(int id) throws PMSException {
		String idRegEx = "[0-9]{3}";
		if (!Pattern.matches(idRegEx, String.valueOf(id))) {
			throw new PMSException("id should be 3 digit number");
		}
	}

	public void validateName(String name) throws PMSException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new PMSException("first letter should be capital and length must be in between 5 to 10");
		}
	}

	public void validateCost(double cost) throws PMSException {

		if (cost < 5000) {
			throw new PMSException("cost should not be less than 5000");
		}
	}

	@Override
	public int addProduct(Product product) throws PMSException {
		return productDao.addProduct(product);
	}

	@Override
	public List<Product> getAllProducts() throws PMSException {
		return productDao.getAllProducts();
	}

	@Override
	public Product searchProduct(int productId) throws PMSException {
		return productDao.searchProduct(productId);
	}
}
