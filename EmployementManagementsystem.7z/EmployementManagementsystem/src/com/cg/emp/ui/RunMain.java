package com.cg.emp.ui;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;
import com.cg.emp.service.EmployeeServiceImpl;

public class RunMain {
	private static final String empName = null;
	static int empId;
	
	//objects
	static Scanner sc = null;
	static EmployeeService empService;
	private static String newName;
	private static float newSal;

	public static void main(String[] args) throws EmployeeException {
		sc = new Scanner(System.in);
		empService = new EmployeeServiceImpl();//Dynamic Binding
		int choice = 0;
		while (true) {
			System.out.println("What do you want to do?");
			System.out.println("1.Add Emp\t2:Fetch All Emp\n");
			System.out.println("3.Search Emp By Id\t4:delete Employee By Id\n");
			System.out.println("5.Search Employee by name\t6.Update employee");
			System.out.println("7.Exit\n");
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				addEmployee();
				break;
			case 2:
				fetchAllDetails();
				break;
			case 3:
				getEmpById(empId);
				break;
			case 4:
				deleteEmployee(empId);
                break;
			case 5:
				sortByName();
		          break;
			case 6:
			case 7:
				updateEmp();
				break;
			default:
			}
		}
	}

	

	private static void addEmployee() {

		while (true) {
			System.out.println("Enter empId:");
			String eid = sc.next();
			try {
				if (empService.validateEmpId(eid)) {//
					while (true) {
						System.out.println("Enter employee name");
						String name = sc.next();
						try {
							if (empService.validateEmpName(name)) {
								while (true) {
									System.out.println("enter employee salary");
									float empSalary = sc.nextFloat();
									Employee employee = new Employee(Integer.parseInt(eid), name, empSalary,
											LocalDate.now());
									empService.addEmployee(employee);//employee stores added details                             
									System.out.println("Employee added" + employee);
									break;
								}
							}
						} catch (Exception e) {
							System.out.println(e);
							//return;
						}
						break;
					}
				}
			} catch (Exception exc) {
				System.out.println(exc);
				//return;
			}
		break;
		}
	}

	public static void fetchAllDetails() {
		HashMap<Integer, Employee> set = empService.fetchAllEmp();
		for (HashMap.Entry m : set.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

	}

	public static void getEmpById(int empId) {
		System.out.println("Enter the employee Id to get name");
		int id = sc.nextInt();
		Employee emp = empService.getEmpById(id);
		System.out.println(emp);
	}

	public static void deleteEmployee(int empId) throws EmployeeException{
		System.out.println("Enter the employee Id to to delete employee");
		int id = sc.nextInt();
		int emp=empService.deleteEmployee(id);

		System.out.println("Employee has been removed "+emp);
	}
	public static void updateEmp()
	{
		System.out.println("enter employee Key");
		int id=sc.nextInt();
		Employee res=empService.getEmpById(id);
		System.out.println("enter employee id to be updated");
		int empId=sc.nextInt();
		System.out.println("enter employee name to be updated");
		String empName=sc.next();
		System.out.println("enter employee salary to be updated");
		float empSal=sc.nextFloat();
		res.setEnmId(empId);
		res.setEmpName(empName);
		res.setEmpSalary(empSal);
		System.out.println(res);
		
	}
	
		 public static void sortByName()
		 
		 {
	List<Employee> l=empService.sortEmpByName();
	
System.out.println("sorting of employee by name");
		Iterator<Employee> i=l.iterator();
		while(i.hasNext())
			{
			System.out.println(i.next());
			}
	
		 }
	 }

