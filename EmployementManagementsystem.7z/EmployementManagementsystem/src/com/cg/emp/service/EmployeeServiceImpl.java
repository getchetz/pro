package com.cg.emp.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.emp.dao.EmployeDAO;
import com.cg.emp.dao.EmployeeDAOImpl;
import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.CollectionUtil;

public class EmployeeServiceImpl implements EmployeeService {
	//Object
	 EmployeDAO employeeDAO=new EmployeeDAOImpl();
	@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		employeeDAO.addEmployee(ee);
		return ee.getEnmId();
	}

	@Override
	public HashMap<Integer,Employee> fetchAllEmp() {
		HashMap<Integer,Employee> obj =employeeDAO.fetchAllEmp();
		return obj;
	}

	@Override
	public Employee getEmpById(int empId) {
		Employee obj1=  employeeDAO.getEmpById(empId);
		return obj1;
	}
	
	@Override
	public int deleteEmployee(int empId)
	{
		int ob=employeeDAO.deleteEmployee(empId);
		return empId;
	}
	/*@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		Employee ud =employeeDAO.updateEmp(empId,newName,newSal);
		return null;
	}*/

	public boolean validateEmpId(String eid) throws EmployeeException {
		Pattern p=Pattern.compile("[0-9]{4}");
		 Matcher m=p.matcher(eid);
		 if(m.matches()) {
			 return true;
		 }
		return false;
	}
		@Override
		public boolean validateEmpSalary(String empSalary) throws EmployeeException {
			Pattern p=Pattern.compile("[0-9]{0,6}");
			 Matcher m=p.matcher(empSalary);
			 if(m.matches()) {
				 return true;
			 }
			return false;
		}

		@Override
		public boolean validateEmpName(String name) throws EmployeeException {
			{
				Pattern p=Pattern.compile("[A-z]{1}[a-z]{1,9}");
			 Matcher m=p.matcher(name);
			 if(m.matches()) 
			 {
				 return true;
			}
			}
			return false;
		}
			

		@Override
		public Employee updateEmp(int empId, String newName, float newSal) {
			// TODO Auto-generated method stub
			return null;
		}

		
		@Override
		public List<Employee> sortEmpByName() {
			List<Employee> e=employeeDAO.sortEmpByName();
			return e;
		}


	}

