package com.cg.emp.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeeService {
public int addEmployee(Employee ee) throws EmployeeException;
public HashMap<Integer,Employee> fetchAllEmp();
public Employee getEmpById(int empId);
public Employee updateEmp (int empId,String newName, float newSal);

public boolean validateEmpName(String name) throws EmployeeException;
public boolean validateEmpId(String eid) throws EmployeeException;
public boolean validateEmpSalary(String empSalary) throws EmployeeException;
public int deleteEmployee(int empId);
public java.util.List<Employee> sortEmpByName();
}

