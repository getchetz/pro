package com.cg.emp.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeDAO {
		public int addEmployee(Employee ee) throws EmployeeException;
		public HashMap<Integer,Employee> fetchAllEmp();
		public Employee getEmpById(int empId);
		public void updateEmp(int empId,String newName, float newSal);
		  public int deleteEmployee(int empId);
		public List<Employee> sortEmpByName();                            

}