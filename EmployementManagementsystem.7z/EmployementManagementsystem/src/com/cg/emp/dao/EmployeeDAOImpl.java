package com.cg.emp.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.CollectionUtil;

public class EmployeeDAOImpl implements EmployeDAO {
	
	//object from collection
	public int addEmployee(Employee ee) throws EmployeeException {
		CollectionUtil.addEmp(ee);
		// TODO Auto-generated method stub
		return ee.getEnmId();
	}


	public HashMap<Integer,Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		HashMap<Integer,Employee> obj =CollectionUtil.fetchAllEmp();
		return obj;
	}
	public Employee getEmpById(int empId) {
		Employee obj1=CollectionUtil.getEmpById(empId);
		return obj1;
	}


	public Employee searchEmployeeByName(String empName) {
		Employee obj2=CollectionUtil.searchEmployeeByname(empName);
		// TODO Auto-generated method stub
		return obj2;
	}

/*
	public void updateEmp(int empId, String newName, float newSal) {
		Employee obj2=Collection.updateEmp(empId, newName,newSal);
		
	}*/

	public boolean validateName(String name) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public int deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		CollectionUtil.deleteEmployee(empId);
	
		return empId;
	}


	@Override
	public void updateEmp(int empId, String newName, float newSal) {
		// TODO Auto-generated method stub
		Employee e=CollectionUtil.updateEmp(empId, newName, newSal);
		return;
	}


	@Override
	public List<Employee> sortEmpByName() {
		List<Employee> e=CollectionUtil.SortByName();
		return e;
	}

	

	
	
}
