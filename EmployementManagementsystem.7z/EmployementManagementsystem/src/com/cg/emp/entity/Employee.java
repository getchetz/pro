package com.cg.emp.entity;

import java.time.LocalDate;
import java.util.Comparator;

public class Employee {
private int empId;
private String empName;
private float empSalary;
private LocalDate empDOJ;
public Employee(int empId, String empName, float f, LocalDate empDOJ) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.empSalary = f;
	this.empDOJ = empDOJ;
}
public int getEnmId() {
	return empId;
}
public void setEnmId(int enmId) {
	this.empId = enmId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public float getEmpSalary() {
	return empSalary;
}
public void setEmpSalary(float empSal) {
	this.empSalary = empSal;
}
public LocalDate getEmpDOJ() {
	return empDOJ;
}
public void setEmpDOJ(LocalDate empDOJ) {
	this.empDOJ = empDOJ;
}
@Override
public String toString() {
	return "Employee [enmId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDOJ=" + empDOJ
			+ "]";
}

//for sorting.
public static Comparator<Employee> getcompname()
{
	Comparator<Employee> comp=new Comparator<Employee>() {@Override
public int compare(Employee o1, Employee o2) {
	// TODO Auto-generated method stub
	return  o1.empName.compareTo(o2.empName);
}
	};
	return comp;
}

public int compare(Object o1, Object o2) {
	// TODO Auto-generated method stub
	return 0;
}


}
