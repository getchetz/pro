package com.cg.emp.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.cg.emp.entity.Employee;

public class CollectionUtil {
	private static HashMap<Integer,Employee> empSet= new HashMap<Integer,Employee>();
static 
{
	empSet.put(1001, new Employee(1001,"Nikhil",45000.0f,LocalDate.of(2019, Month.MARCH, 21)));
	empSet.put(1002, new Employee(1002,"Shiva",51000.0F,LocalDate.of(2019, Month.APRIL, 23)));
	empSet.put(1003, new Employee(1003,"Ram",52000.0F,LocalDate.of(2019, Month.MAY, 25)));
	empSet.put(1004, new Employee(1004,"Ravi",54000.0F,LocalDate.of(2019, Month.JUNE, 22)));
}

//method for sorting
private static List<Employee> list=new ArrayList<Employee>();
static 
{
	list.add(new Employee(1001,"Nikhil",45000.0f,LocalDate.of(2019, Month.MARCH, 21)));
	list.add( new Employee(1002,"Shiva",51000.0F,LocalDate.of(2019, Month.APRIL, 23)));
	list.add(new Employee(1003,"Ram",52000.0F,LocalDate.of(2019, Month.MAY, 25)));
	list.add(new Employee(1004,"Ravi",54000.0F,LocalDate.of(2019, Month.JUNE, 22)));
}

public static void addEmp(Employee emp)
{
	Employee employee =empSet.put(144, emp);
}

public static HashMap<Integer,Employee> fetchAllEmp() {
	
	{
	return empSet;
	}
}
	
	public static  Employee getEmpById(int empId)
	{
		Employee emp=empSet.get(empId );
		return emp;
}
	public static int deleteEmployee(int empId)
	{
		empSet.remove(empId);
		System.out.println("After deletion:"+empSet);
		return empId;
	}
	public static Employee updateEmp(int empId,String newName, float newSal)
	{
		return empSet.get(newName);
	}

	public static Employee searchEmployeeByname(String empName) {
		Employee emp=empSet.get(empName);
		return emp;
		// TODO Auto-generated method stub
		
	}
	
	public static List<Employee> SortByName()

	{
		Collection<Employee> v=empSet.values();
		Collections.sort(list, Employee.getcompname());
	   return list;

	}
	
	
	
	
}
