package com.cg.pizzaorder.entity;

public class PizzaOrder {
private int orderId;
private int customerId;
private double totelPrice;
public PizzaOrder() {
	super();
	// TODO Auto-generated constructor stub
}
public PizzaOrder(int orderId, int customerId, double totelPrice) {
	super();
	this.orderId = orderId;
	this.customerId = customerId;
	this.totelPrice = totelPrice;
}
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public double getTotelPrice() {
	return totelPrice;
}
public void setTotelPrice(double totelPrice) {
	this.totelPrice = totelPrice;
}
@Override
public String toString() {
	return "PizzaOrder [orderId=" + orderId + ", customerId=" + customerId + ", totelPrice=" + totelPrice + "]";
}

}
