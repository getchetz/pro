package com.cg.pizzaorder.exception;

public class PizzaException extends Exception {

	public PizzaException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
