package com.cg.pizzaorder.service;

import java.util.regex.Pattern;

import com.cg.pizzaorder.dao.PizzaOrderDaoImp;
import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.entity.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderServiceImp implements PizzaOrderService {
	PizzaOrderDaoImp podi=new PizzaOrderDaoImp();

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
	int pizzas=podi.placeOrder(customer, pizza);
		return pizzas;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) throws PizzaException {
		PizzaOrder p=podi.getOrderDetails(orderId);
		return p;
	}
	@Override
public boolean validatecusName(String cusName)throws PizzaException{
	if(Pattern.matches("[a-zA-Z]{7}",cusName))
	{
		return true;
	}
	else
	{
		return false;
	}
	
}
	@Override
public boolean validatephone(String phone)throws PizzaException{
	if(Pattern.matches("[0-9]{10}",phone))
	{
		return true;
	}
	else
	{
		return false;
	}
}

	
}
