package com.cg.pizzaorder.service;

import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.entity.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public interface PizzaOrderService {
public int placeOrder(Customer customer,PizzaOrder pizza)throws PizzaException;	
public  PizzaOrder getOrderDetails(int orderId) throws PizzaException;

boolean validatephone(String phone) throws PizzaException;
boolean validatecusName(String cusName) throws PizzaException;
 }
