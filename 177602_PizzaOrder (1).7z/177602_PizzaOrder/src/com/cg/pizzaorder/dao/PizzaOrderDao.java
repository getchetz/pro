package com.cg.pizzaorder.dao;

import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.entity.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public interface PizzaOrderDao {
	public int placeOrder(Customer customer,PizzaOrder pizza)throws PizzaException;	
	public  PizzaOrder getOrderDetails(int orderId) throws PizzaException;
	
		
	
}
