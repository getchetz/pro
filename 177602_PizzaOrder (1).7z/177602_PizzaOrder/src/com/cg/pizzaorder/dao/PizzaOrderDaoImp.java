package com.cg.pizzaorder.dao;

import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.entity.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.util.PizzaCustomerCollection;

public class PizzaOrderDaoImp implements PizzaOrderDao {
	PizzaCustomerCollection pcc=new PizzaCustomerCollection();

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		int pizzas=pcc.placeOrder(customer, pizza);
		return pizzas;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) throws PizzaException {
	PizzaOrder p=pcc.getOrderDetails(orderId);
		return p;
	}

	

	

}
