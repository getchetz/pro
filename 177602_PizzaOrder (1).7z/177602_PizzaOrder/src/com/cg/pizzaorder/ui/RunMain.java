package com.cg.pizzaorder.ui;

import java.util.Scanner;

import javax.naming.ldap.SortKey;

import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.entity.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.PizzaOrderServiceImp;

public class RunMain {
static PizzaOrderServiceImp posi=new PizzaOrderServiceImp();

public static void main(String[] args) throws PizzaException {
	System.out.println("welcome to pizzahut");
	while(true) {
	System.out.println("select menu");
	System.out.println("1. For Place Order");
	System.out.println("2.For Display Order Details");
	System.out.println("3.For exit");
	Scanner sc=new Scanner(System.in);
	int choice=sc.nextInt();
	switch(choice)
	{
	case 1:
		placeOrder();
		
		break;
		
	case 2:
		getOrderDetails();
		break;
		
	case 3:
		System.exit(0);
		break;
	}
	}
}

public static void getOrderDetails() throws PizzaException{
System.out.println("enter order id");
Scanner sc=new Scanner(System.in);
int orderid=sc.nextInt();
PizzaOrder p=posi.getOrderDetails(orderid);
System.out.println(p);
	
}

private static void placeOrder()throws PizzaException {
	int mushroom=50;
	int panner=85;
	int capsicum=30;
	int jalapeno=70;
	double totalprice=300;
	
	Scanner sc=new Scanner(System.in);
	System.out.println("enter customer name");
	String cusName=sc.nextLine();
	try {
	if(posi.validatecusName(cusName)==true) 
		
	
		
	{
	System.out.println("enter customer address");
	String address=sc.nextLine();
	System.out.println("enter customer mobile number");
	String phone=sc.nextLine();
	try {
		
	if(posi.validatephone(phone)==true) 
		

	
	{
		
	
	System.out.println("enter preferd topping");
	System.out.println("select 1 for Capsicum");
	System.out.println("select 2 for Mushroom");
	System.out.println("select 3 for Jalapeno");
	System.out.println("select 4 for Panner");
	int choice=sc.nextInt();
	int max=5000;
	int min=1;
	int range=max-min+1;
	int orderId=(int)(Math.random()*range)+min;
	int max1=4000;
	int min1=2;
	int range1=max1-min1+1;
	int customerId=(int)(Math.random()*range1)+min1;
	Customer cc=new Customer(cusName,address,phone);
	PizzaOrder po=new PizzaOrder(orderId,customerId,totalprice);
	int pp=posi.placeOrder(cc, po);

	switch(choice)
	{
	
	case 1:
		System.out.println("price of pizza is "+(totalprice+=capsicum));
		
		System.out.println("order details are orderId is:"+orderId);
		System.out.println("customer id is :"+customerId);
		System.out.println("purchase successful");
		
		
		break;
		
	
	case 2:
		System.out.println("price of pizza is "+(totalprice+=mushroom));
		
		
		System.out.println("order details are orderId is:"+orderId);
		System.out.println("customer id is :"+customerId);
		System.out.println("purchase successful");
		break;
		
	
	case 3:
		System.out.println("price of pizza is "+(totalprice+=jalapeno));
	
		System.out.println("order details are orderId is:"+orderId);
		System.out.println("customer id is :"+customerId);
		System.out.println("purchase successful");
		break;
		
	
	case 4:
		System.out.println("price of pizza is "+(totalprice+=panner));
		System.out.println("order details are orderId is:"+orderId);
		System.out.println("customer id is :"+customerId);
		System.out.println("purchase successful");
		break;
		
	}
		
	}
		else
		{
		System.out.println("enter valid mobile number with 10 digits");
	}
	
	
	
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}
	else
	{
		System.out.println("enter valid name");
	}
	
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
}

}

