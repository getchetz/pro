package com.cg.pa.dto;

public class PizzaOrder {

	private int id;
	private int customerId;
	private double totalPrice;

	public PizzaOrder() {
		// TODO Auto-generated constructor stub
	}

	public PizzaOrder(int id, int customerId, double totalPrice) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return "PizzaOrder [id=" + id + ", customerId=" + customerId + ", totalPrice=" + totalPrice + "]";
	}

}
