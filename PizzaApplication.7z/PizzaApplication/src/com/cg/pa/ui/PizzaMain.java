package com.cg.pa.ui;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import com.cg.pa.dao.PizzaDAOImpl;
import com.cg.pa.dto.Customer;
import com.cg.pa.dto.PizzaOrder;
import com.cg.pa.exceptions.PAException;
import com.cg.pa.service.IPizzaService;
import com.cg.pa.service.PizzaServiceImpl;

public class PizzaMain {

	public static void main(String[] args) {

		Scanner scanner = null;

		String continueChoice = "";
		IPizzaService service = new PizzaServiceImpl();

		do {

			System.out.println("1.place order");
			System.out.println("2.display order");
			System.out.println("3.Exit");

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");

				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					String name = "";

					switch (choice) {
					case 1:

						boolean nameFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter name of the customer");
							name = scanner.nextLine();
							try {
								service.validateName(name);
								nameFlag = true;
								break;

							} catch (PAException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						String address = "";
						boolean addressFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter address of the customer");
							address = scanner.nextLine();
							try {
								service.validateAddress(address);
								addressFlag = true;
								break;

							} catch (PAException e) {
								addressFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!addressFlag);

						String phone = "";
						boolean phoneFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter phone number of the customer");
							phone = scanner.nextLine();
							try {
								service.validatePhone(phone);
								phoneFlag = true;
								break;

							} catch (PAException e) {
								phoneFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!phoneFlag);

						String pizzaType = "";
						boolean pizzaFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter pizza name");
							pizzaType = scanner.nextLine();
							try {
								service.validatePizza(pizzaType);
								pizzaFlag = true;
								break;

							} catch (PAException e) {
								pizzaFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!pizzaFlag);

						Map<String, Integer> map = new TreeMap<>();
						map.put("Capsicum", 30);
						map.put("Mushroom", 50);
						map.put("Jalapeno", 70);
						map.put("paneer", 85);

						int pizzaCost = 0;

						Set<String> set = map.keySet();
						for (String pizzaName : set) {
							if (pizzaName.equalsIgnoreCase(pizzaType)) {
								pizzaCost = map.get(pizzaName) + 350;
								break;
							}
						}
						System.out.print("Price :" + pizzaCost);

						LocalDate localDate = LocalDate.now();
						System.out.println("order date:" + localDate);

						Customer customer = new Customer(name, address, phone);

						PizzaOrder order = new PizzaOrder();
						order.setTotalPrice(pizzaCost);

						try {
							int orderId = service.placeOrder(customer, order);
							System.out.println("order place with the id " + orderId);
						} catch (PAException e) {
							System.err.println(e.getMessage());
						}

						break;

					case 2:

						int orderId = 0;
						boolean orderIdFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("order id");
							try {
								orderId = scanner.nextInt();
								service.validateOrderId(orderId);
								orderIdFlag = true;
								break;

							} catch (InputMismatchException e) {
								orderIdFlag = false;
								System.err.println(e.getMessage());
							} catch (PAException e) {
								System.err.println(e.getMessage());
							}

						} while (!orderIdFlag);

						try {
							PizzaOrder pizzaOrder = service.getorderDetails(orderId);
							int custId = pizzaOrder.getCustomerId();

							Customer customer2 = PizzaDAOImpl.getCustomer(custId);
							System.out.println(customer2.getCustName());
							System.out.println(customer2.getAddress());
							System.out.println(customer2.getPhone());

						} catch (PAException e) {
							System.err.println(e.getMessage());
						}

						break;

					case 3:
						System.exit(0);

					default:
						System.out.println("Enter 1,2 or 3");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("enter only digits");
				}

			} while (!choiceFlag);

			scanner = new Scanner(System.in);
			System.out.println("do u want to continue again(yes/no)");
			continueChoice = scanner.next();
		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}
}
